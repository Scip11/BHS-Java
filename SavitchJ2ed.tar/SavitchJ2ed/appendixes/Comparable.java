public interface Comparable
{
    public boolean comesBefore(Object otherObject);
}
public class LinkedListException extends Exception
{
    public LinkedListException()
    {
        super("Linked List Exception");
    }

    public LinkedListException(String message)
    {
        super(message);
    }
}
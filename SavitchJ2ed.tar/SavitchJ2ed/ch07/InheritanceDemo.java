
public class InheritanceDemo
{
    public static void main(String[] args) 
    {
        Student s = new Student();
        
        s.setName("Warren Peace");
        s.setStudentNumber(2001);
        s.writeOutput();
    }
}
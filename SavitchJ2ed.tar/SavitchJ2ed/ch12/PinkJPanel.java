import javax.swing.*;
import java.awt.*;

public class PinkJPanel extends JPanel
{
    public PinkJPanel()
    {
        setBackground(Color.pink);
    }
}